<?php
include_once 'top.php';
include_once 'menu.php';
?>
<div id="layoutSidenav_content">
    <main>
        <div class="container-fluid px-4">
            <h1 class="mt-4">Produk Lama</h1>
            <p class="mb-4">Ini adalah halaman produk lama.</p>
            <p>Daftar produk lama:</p>
            <ul>
                <li>Produk 1</li>
                <li>Produk 2</li>
                <li>Produk 3</li>
            </ul>
        </div>
    </main>
    <?php include_once 'bottom.php'; ?>
</div>
