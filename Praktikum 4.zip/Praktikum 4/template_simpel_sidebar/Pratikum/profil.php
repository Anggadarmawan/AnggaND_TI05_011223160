<?php
include_once 'top.php';
include_once 'menu.php';
?>
<div id="layoutSidenav_content">
    <main>
        <div class="container-fluid px-4">
            <h1 class="mt-4"><i class="fas fa-user"></i> Profil</h1>
            <p class="mb-4">Ini adalah halaman profil.</p>
        </div>
    </main>
    <?php include_once 'bottom.php'; ?>
</div>
