<?php
include_once 'top.php';
include_once 'menu.php';
?>
<div id="layoutSidenav_content">
    <main>
        <div class="container-fluid px-4">
            <h1 class="mt-4">Produk Baru</h1>
            <p class="mb-4">Ini adalah halaman produk baru.</p>
            <p>Daftar produk baru:</p>
            <ul>
                <li>Produk A</li>
                <li>Produk B</li>
                <li>Produk C</li>
            </ul>
        </div>
    </main>
    <?php include_once 'bottom.php'; ?>
</div>
