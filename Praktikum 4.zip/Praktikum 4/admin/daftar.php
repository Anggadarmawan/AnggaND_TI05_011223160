<?php

require_once './top.php';
require_once './menu.php';


?>

<div class="container-fluid px-4">
    <h1 class="mt-4">Silahkan Isi Form Pendaftaran</h1>
</div>

<?php

require_once './bottom.php';

?>